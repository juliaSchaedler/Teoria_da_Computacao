import csv
import time


def carregar_dados(caminho_arquivo):
  dados = []
  with open(caminho_arquivo, 'r') as arquivo:
    leitor = csv.reader(arquivo)
    for linha in leitor:
      dados.append(linha)  # Suponha que cada linha seja uma lista de valores
  return dados


#-------------------------------------FUNÇÕES DE ORDENAÇÃO ------------------------------------

def bubble_sort(arr):
  n = len(arr)
  for i in range(n):
    for j in range(0, n - i - 1):
      if arr[j] > arr[j + 1]:
        arr[j], arr[j + 1] = arr[j + 1], arr[j]


def quick_sort(arr):
  if len(arr) <= 1:
    return arr
  else:
    pivot = arr[0]
    lesser = [x for x in arr[1:] if x <= pivot]
    greater = [x for x in arr[1:] if x > pivot]
    return quick_sort(lesser) + [pivot] + quick_sort(greater)


def merge_sort(arr):
  if len(arr) <= 1:
    return arr

  def merge(left, right):
    result = []
    i = j = 0

    while i < len(left) and j < len(right):
      if left[i] < right[j]:
        result.append(left[i])
        i += 1
      else:
        result.append(right[j])
        j += 1

    result.extend(left[i:])
    result.extend(right[j:])
    return result

  middle = len(arr) // 2
  left = arr[:middle]
  right = arr[middle:]

  left = merge_sort(left)
  right = merge_sort(right)

  return merge(left, right)

#------------------------------RECEBIMENTO DO DATASET --------------------------------

caminho_arquivo_csv = "spotify-2023.csv"
dados = carregar_dados(caminho_arquivo_csv)

# Faça uma cópia dos dados para cada algoritmo
dados_bubble_sort = dados.copy()
dados_quick_sort = dados.copy()
dados_merge_sort = dados.copy()

# Medição do tempo para o Bubble Sort
inicio = time.time()
bubble_sort(dados_bubble_sort)
tempo_bubble_sort = time.time() - inicio

# Medição do tempo para o Quick Sort
inicio = time.time()
quick_sort(dados_quick_sort)
tempo_quick_sort = time.time() - inicio

# Medição do tempo para o Merge Sort
inicio = time.time()
merge_sort(dados_merge_sort)
tempo_merge_sort = time.time() - inicio

print(f"Tempo de execução do Bubble Sort: {tempo_bubble_sort} segundos")
print(f"Tempo de execução do Quick Sort: {tempo_quick_sort} segundos")
print(f"Tempo de execução do Merge Sort: {tempo_merge_sort} segundos")
